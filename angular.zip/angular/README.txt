run npm init -y
run npm install express --save
run npm  install mongoose --save
run npm install body-parser --save

monogo db needs to be running locally
navigate to mongo folder and open terminal in folder. 
tab to run mongod.exe

Add a few students to get started